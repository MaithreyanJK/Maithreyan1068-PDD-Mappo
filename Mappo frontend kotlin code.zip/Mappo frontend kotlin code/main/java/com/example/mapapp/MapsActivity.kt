package com.example.mapapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.*
import com.google.maps.android.SphericalUtil
import android.view.LayoutInflater
import android.location.Geocoder
import android.app.Activity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.mapapp.network.ApiResponse
import com.example.mapapp.network.RetrofitClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.util.Log
import java.util.Locale



class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    companion object {
        private const val SEARCH_REQUEST_CODE = 101
    }


    private lateinit var mMap: GoogleMap
    private var selectedMapType = "Normal"  // Default is Normal map
    private val locationPermissionRequestCode = 1001
    private val markedLocations = mutableListOf<LatLng>()
    private val markers = mutableListOf<Marker>()
    private var polyline: Polyline? = null
    private var polygon: Polygon? = null
    private var measuringDistance = false
    private var distanceUnit = "km"
    private var areaUnit = "square_meter"
    private lateinit var fusedLocationClient: FusedLocationProviderClient


    private lateinit var btnSaveMeasurement: Button // Ensure it is declared

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val mapFragment = SupportMapFragment.newInstance()
        supportFragmentManager.beginTransaction()
            .replace(R.id.map, mapFragment)
            .commit()

        mapFragment.getMapAsync(this)

        val clearButton = findViewById<Button>(R.id.btnClear)
        val measureTypeButton = findViewById<Button>(R.id.btnMeasureType)
        val menuButton = findViewById<ImageButton>(R.id.btnMenu)
        val searchButton = findViewById<ImageButton>(R.id.btnSearch)
        val spinnerMapType = findViewById<Spinner>(R.id.spinnerMapType) // Spinner for Map Types

        // Initialize Save Measurement Button
        btnSaveMeasurement = findViewById(R.id.btnSaveMeasurement)
        btnSaveMeasurement.visibility = View.GONE // Hide initially

        btnSaveMeasurement.setOnClickListener {
            showSaveMeasurementDialog()
        }

        clearButton.setOnClickListener {
            clearMap()
            btnSaveMeasurement.visibility = View.GONE // Hide Save button when clearing map
        }

        measureTypeButton.setOnClickListener {
            showMeasurementDialog()
            btnSaveMeasurement.visibility = View.VISIBLE // Show Save button when measurement starts
        }

        menuButton.setOnClickListener { showPopupMenu() }
        searchButton.setOnClickListener { openSearchActivity() }

        // Handle search query if received
        val locationQuery = intent.getStringExtra("LOCATION_QUERY")
        if (!locationQuery.isNullOrEmpty()) {
            searchLocation(locationQuery)
        }

        // Set up the Spinner for Map Types
        setupMapTypeSpinner(spinnerMapType)
    }


    private fun setupMapTypeSpinner(spinner: Spinner) {
        val mapTypes = arrayOf("Normal", "Satellite", "Terrain", "Hybrid")

        // Use a custom layout for styling
        val adapter = ArrayAdapter(this, R.layout.custom_spinner_item, mapTypes)
        adapter.setDropDownViewResource(R.layout.custom_spinner_item) // Apply to dropdown as well
        spinner.adapter = adapter

        // Hide the initial text by selecting an empty state
        spinner.setSelection(-1, false)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == -1) return // Ignore selection if no valid item is chosen

                selectedMapType = mapTypes[position]  // Store selected type
                handleGlobeView(mMap.cameraPosition.zoom)  // Apply the change based on zoom
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }
    }




    private fun handleGlobeView(zoomLevel: Float) {
        if (zoomLevel < 5f) {
            // Instead of setting MAP_TYPE_NONE, keep a base map type
            mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE // You can change this to your preference
            mMap.setMinZoomPreference(2f) // Allow zooming out while keeping the map visible
        } else {
            // Restore the selected map type
            when (selectedMapType) {
                "Normal" -> mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                "Satellite" -> mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                "Terrain" -> mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
                "Hybrid" -> mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
            }
            mMap.resetMinMaxZoomPreference() // Reset zoom limits
        }
    }


    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Enable user location if permissions are granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.isMyLocationEnabled = true
        }

        // Enable tilt, zoom, and rotation for better Globe View effect
        mMap.uiSettings.isTiltGesturesEnabled = true
        mMap.uiSettings.isZoomGesturesEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true

        // Set a listener to handle zoom changes (for Globe View)
        mMap.setOnCameraMoveListener {
            val zoomLevel = mMap.cameraPosition.zoom
            handleGlobeView(zoomLevel) // Switch to Globe View when zoomed out
        }

        // Set the map click listener here
        mMap.setOnMapClickListener { latLng ->
            addMarker(latLng)
            moveCameraToLocation(latLng)

            if (measuringDistance) {
                updatePolyline()
                if (markedLocations.size > 1) calculateDistance()
            } else {
                updatePolygon()
                if (markedLocations.size > 2) calculateArea()
            }

            // Show Save Button only when markers are added
            if (markedLocations.isNotEmpty()) {
                btnSaveMeasurement.visibility = View.VISIBLE
            }
        }
    }

    // Step 3: Function to start SearchActivity
    private fun openSearchActivity() {
        val intent = Intent(this, SearchActivity::class.java)
        startActivityForResult(intent, SEARCH_REQUEST_CODE)
    }



    private fun searchLocation(locationName: String) {
        if (locationName.isEmpty()) {
            Toast.makeText(this, "Enter a location", Toast.LENGTH_SHORT).show()
            return
        }

        val geocoder = Geocoder(this)
        try {
            val addressList = geocoder.getFromLocationName(locationName, 1)
            if (!addressList.isNullOrEmpty()) {
                val address = addressList[0]
                val latLng = LatLng(address.latitude, address.longitude)

                // Clear previous search markers
                mMap.clear()

                // Add marker for the searched location
                val marker = mMap.addMarker(
                    MarkerOptions()
                        .position(latLng)
                        .title(locationName)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                )
                marker?.showInfoWindow()

                // Move camera to searched location
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12f))
            } else {
                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error fetching location", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SEARCH_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val locationQuery = data?.getStringExtra("LOCATION_QUERY")
            if (!locationQuery.isNullOrEmpty()) {
                searchLocation(locationQuery)
            }
        }
    }


    @SuppressLint("MissingPermission")
    private fun enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                locationPermissionRequestCode
            )
        }
    }

    private fun addMarker(latLng: LatLng) {
        val formattedCoordinates = formatCoordinates(latLng.latitude, latLng.longitude)
        val marker = mMap.addMarker(
            MarkerOptions()
                .position(latLng)
                .title(formattedCoordinates)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
        )
        marker?.let { markers.add(it) }
        markedLocations.add(latLng)
        marker?.showInfoWindow()
    }

    private fun moveCameraToLocation(latLng: LatLng) {
        val currentZoom = mMap.cameraPosition.zoom  // Get current zoom level
        val cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, if (markers.size > 1) currentZoom else 15f)
        mMap.animateCamera(cameraUpdate)
    }


    private fun updatePolyline() {
        polyline?.remove()
        if (markedLocations.size > 1) {
            polyline = mMap.addPolyline(
                PolylineOptions()
                    .addAll(markedLocations)
                    .width(8f)
                    .color(ContextCompat.getColor(this, R.color.black))
                    .geodesic(true)
            )
        }
    }

    private fun updatePolygon() {
        polygon?.remove()
        if (markedLocations.size > 2) {
            polygon = mMap.addPolygon(
                PolygonOptions()
                    .addAll(markedLocations)
                    .strokeColor(ContextCompat.getColor(this, R.color.black))
                    .fillColor(ContextCompat.getColor(this, R.color.transparent_blue))
            )
        }
    }

    private fun showMeasurementPanel() {
        val measurementPanel = findViewById<LinearLayout>(R.id.measurementPanel)
        measurementPanel.visibility = View.VISIBLE // Show the panel when a measurement is made
    }


    private fun calculateDistance() {
        val totalDistanceMeters = markedLocations.zipWithNext { a, b ->
            SphericalUtil.computeDistanceBetween(a, b)
        }.sum()

        val distanceText = when (distanceUnit) {
            "meter" -> String.format(Locale.US, "%.2f m", totalDistanceMeters)
            "feet" -> String.format(Locale.US, "%.2f ft", totalDistanceMeters * 3.28084)
            "mile" -> String.format(Locale.US, "%.3f mi", totalDistanceMeters / 1609.34)
            "yard" -> String.format(Locale.US, "%.2f yd", totalDistanceMeters * 1.09361)
            else -> String.format(Locale.US, "%.2f km", totalDistanceMeters / 1000.0)
        }

        findViewById<TextView>(R.id.tvDistance).text = "Distance: $distanceText"
        findViewById<TextView>(R.id.tvPerimeter).text = "Perimeter: $distanceText" // Same as total distance
        showMeasurementPanel()
    }

    private fun calculateArea() {
        val areaInSquareMeters = SphericalUtil.computeArea(markedLocations)

        val perimeterMeters = markedLocations.zipWithNext { a, b ->
            SphericalUtil.computeDistanceBetween(a, b)
        }.sum() + SphericalUtil.computeDistanceBetween(markedLocations.last(), markedLocations.first()) // Closing the polygon

        val areaText = when (areaUnit) {
            "square_meter" -> String.format(Locale.US, "%.2f m²", areaInSquareMeters)
            "acre" -> String.format(Locale.US, "%.4f acres", areaInSquareMeters / 4046.86)
            "square_inch" -> String.format(Locale.US, "%.2f in²", areaInSquareMeters * 1550.0031)
            "square_yard" -> String.format(Locale.US, "%.2f yd²", areaInSquareMeters * 1.19599)
            else -> String.format(Locale.US, "%.2f ft²", areaInSquareMeters * 10.7639)
        }

        val perimeterText = when (distanceUnit) {
            "meter" -> String.format(Locale.US, "%.2f m", perimeterMeters)
            "feet" -> String.format(Locale.US, "%.2f ft", perimeterMeters * 3.28084)
            else -> String.format(Locale.US, "%.2f km", perimeterMeters / 1000.0)
        }

        findViewById<TextView>(R.id.tvArea).text = "Area: $areaText"
        findViewById<TextView>(R.id.tvPerimeter).text = "Perimeter: $perimeterText"
        showMeasurementPanel()
    }




    private fun formatCoordinates(lat: Double, lng: Double): String {
        val latDir = if (lat >= 0) "N" else "S"
        val lngDir = if (lng >= 0) "E" else "W"
        return "${"%.4f".format(kotlin.math.abs(lat))}° $latDir, ${"%.4f".format(kotlin.math.abs(lng))}° $lngDir"
    }


    private fun showSaveMeasurementDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_save_measurement, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val etPlace = dialogView.findViewById<EditText>(R.id.etPlace)
        val btnSave = dialogView.findViewById<Button>(R.id.btnSave)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        btnSave.setOnClickListener {
            val placeName = etPlace.text.toString().trim()
            if (placeName.isEmpty()) {
                Toast.makeText(this, "Enter a place name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Retrieve user_id using SessionManager
            // Retrieve user_id using SessionManager
            // Retrieve user_id using SessionManager
            val sessionManager = SessionManager(this)
            val userIdString = sessionManager.getUserId()

            if (userIdString.isNullOrEmpty()) {  // Check if user ID is missing
                Toast.makeText(this, "User not logged in (No valid user_id)", Toast.LENGTH_SHORT).show()
                Log.e("SaveMeasurement", "Error: No valid user_id found in SessionManager")
                return@setOnClickListener
            }

// Convert userIdString to Int safely
            val userId = userIdString.toIntOrNull()
            if (userId == null) {
                Toast.makeText(this, "Invalid user ID format", Toast.LENGTH_SHORT).show()
                Log.e("SaveMeasurement", "Error: user_id is not a valid integer ($userIdString)")
                return@setOnClickListener
            }

            Log.d("SaveMeasurement", "Retrieved user_id: $userId")

            val area = SphericalUtil.computeArea(markedLocations)
            val perimeter = markedLocations.zipWithNext { a, b ->
                SphericalUtil.computeDistanceBetween(a, b)
            }.sum() + SphericalUtil.computeDistanceBetween(markedLocations.last(), markedLocations.first())

            saveMeasurementToServer(userId, area, perimeter, areaUnit, placeName) // Now userId is Int
            dialog.dismiss()


        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }



    private fun saveMeasurementToServer(userId: Int, area: Double, perimeter: Double, unit: String, place: String) {
        val apiService = RetrofitClient.getInstance(this)

        // Round area and perimeter to 2 decimal places before sending
        val formattedArea = String.format(Locale.US, "%.2f", area).toDouble()
        val formattedPerimeter = String.format(Locale.US, "%.2f", perimeter).toDouble()

        val call = apiService.saveMeasurement(userId, formattedArea, formattedPerimeter, unit, place)

        call.enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful && response.body()?.status == true) {
                    Toast.makeText(this@MapsActivity, "Measurement saved successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MapsActivity, "Failed to save measurement", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Toast.makeText(this@MapsActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }




    private fun showMeasurementDialog() {
        // Inflate the custom layout
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.custom_measurement_dialog, null)

        // Create the dialog
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        // Set background color to fully white
        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        // Get buttons from the layout
        val btnDistance = dialogView.findViewById<Button>(R.id.btnDistance)
        val btnArea = dialogView.findViewById<Button>(R.id.btnArea)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        // Handle button clicks
        btnDistance.setOnClickListener {
            measuringDistance = true
            clearMap()
            showDistanceUnitDialog()
            dialog.dismiss()
        }

        btnArea.setOnClickListener {
            measuringDistance = false
            clearMap()
            showAreaUnitDialog()
            dialog.dismiss()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        // Show the dialog
        dialog.show()
    }

    private fun showDistanceUnitDialog() {
        val inflater = LayoutInflater.from(this)  // Get LayoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_unit_selection2, null)  // Inflate layout

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)  // Pass the inflated View
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white) // Set background color

        // Get buttons from the layout
        val btnMeter = dialogView.findViewById<Button>(R.id.btnMeter)
        val btnFeet = dialogView.findViewById<Button>(R.id.btnFeet)
        val btnMile = dialogView.findViewById<Button>(R.id.btnMile)
        val btnYard = dialogView.findViewById<Button>(R.id.btnYard)
        val btnKilometer = dialogView.findViewById<Button>(R.id.btnKilometer)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        // Set click listeners
        btnMeter.setOnClickListener {
            distanceUnit = "meter"
            dialog.dismiss()
        }
        btnFeet.setOnClickListener {
            distanceUnit = "feet"
            dialog.dismiss()
        }
        btnMile.setOnClickListener {
            distanceUnit = "mile"
            dialog.dismiss()
        }
        btnYard.setOnClickListener {
            distanceUnit = "yard"
            dialog.dismiss()
        }
        btnKilometer.setOnClickListener {
            distanceUnit = "km"
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showAreaUnitDialog() {
        val inflater = LayoutInflater.from(this)  // Get LayoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_area_selection, null)  // Inflate layout

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)  // Pass the inflated View
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white) // Set background color

        // Get buttons from the layout
        val btnSquareMeter = dialogView.findViewById<Button>(R.id.btnSquareMeter)
        val btnAcre = dialogView.findViewById<Button>(R.id.btnAcre)
        val btnSquareInch = dialogView.findViewById<Button>(R.id.btnSquareInch)
        val btnSquareYard = dialogView.findViewById<Button>(R.id.btnSquareYard)
        val btnSquareFeet = dialogView.findViewById<Button>(R.id.btnSquareFeet)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        // Set click listeners
        btnSquareMeter.setOnClickListener {
            areaUnit = "square_meter"
            dialog.dismiss()
        }
        btnAcre.setOnClickListener {
            areaUnit = "acre"
            dialog.dismiss()
        }
        btnSquareInch.setOnClickListener {
            areaUnit = "square_inch"
            dialog.dismiss()
        }
        btnSquareYard.setOnClickListener {
            areaUnit = "square_yard"
            dialog.dismiss()
        }
        btnSquareFeet.setOnClickListener {
            areaUnit = "square_feet"
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun showSosBottomSheet() {
        val sosBottomSheet = SosBottomSheet()
        sosBottomSheet.show(supportFragmentManager, "SOSBottomSheet")
    }



    private fun showPopupMenu() {
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.custom_popup_menu, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        val btnHome = dialogView.findViewById<Button>(R.id.btnHome)
        val btnMeasurements = dialogView.findViewById<Button>(R.id.btnMeasurements)
        val btnRoute = dialogView.findViewById<Button>(R.id.btnRoute)
        val btnSettings = dialogView.findViewById<Button>(R.id.btnSettings)
        val btnSosEmergency = dialogView.findViewById<Button>(R.id.btnSosEmergency) // Add this
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        btnHome.setOnClickListener {
            navigateTo(MapsActivity::class.java)
            dialog.dismiss()
        }
        btnMeasurements.setOnClickListener {
            navigateTo(MeasurementActivity::class.java)
            dialog.dismiss()
        }
        btnRoute.setOnClickListener {
            navigateTo(RoutePlannerActivity::class.java)
            dialog.dismiss()
        }
        btnSettings.setOnClickListener {
            navigateTo(SettingsActivity::class.java)
            dialog.dismiss()
        }
        btnSosEmergency.setOnClickListener {
            showSosBottomSheet() // Open SOS Bottom Sheet
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }



    private fun navigateTo(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        startActivity(intent)
    }

    private fun clearMap() {
        mMap.clear()
        markedLocations.clear()

        // Hide the measurement panel
        val measurementPanel = findViewById<LinearLayout>(R.id.measurementPanel)
        measurementPanel.visibility = View.GONE
    }

}
