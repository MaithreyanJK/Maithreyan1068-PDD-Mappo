package com.example.mapapp.network

import okhttp3.Interceptor
import okhttp3.Response
import android.os.Handler
import android.os.Looper
import com.example.mapapp.LoadingDialog

class LoadingInterceptor(private val context: android.content.Context) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        // Show loader on main thread
        Handler(Looper.getMainLooper()).post {
            LoadingDialog.show(context)
        }

        val response = chain.proceed(chain.request()) // Execute API call

        // Hide loader on main thread after API call completes
        Handler(Looper.getMainLooper()).post {
            LoadingDialog.dismiss()
        }

        return response
    }
}
