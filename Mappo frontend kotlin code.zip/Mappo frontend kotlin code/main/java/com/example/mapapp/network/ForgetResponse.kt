package com.example.mapapp.network

import com.google.gson.annotations.SerializedName

data class ForgetResponse(
    @SerializedName("status") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("data") val data: String
)
