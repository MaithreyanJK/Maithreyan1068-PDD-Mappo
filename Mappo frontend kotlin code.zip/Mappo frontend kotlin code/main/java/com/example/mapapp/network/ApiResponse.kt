package com.example.mapapp.network

data class ApiResponse(
    val status: Boolean,
    val message: String,
    val data: MeasurementData?
)

data class MeasurementData(
    val id: Int,
    val user_id: Int,
    val area: Double,
    val perimeter: Double,
    val unit: String,
    val place: String
)

