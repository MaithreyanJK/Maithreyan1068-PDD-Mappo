package com.example.mapapp.network

data class LoginResponse(
    val status: Boolean,
    val message: String,
    val data: UserData?
)

data class UserData(
    val id: String,  // Ensure it's 'id' to match PHP response
    val username: String,
    val mobile_number: String
)
