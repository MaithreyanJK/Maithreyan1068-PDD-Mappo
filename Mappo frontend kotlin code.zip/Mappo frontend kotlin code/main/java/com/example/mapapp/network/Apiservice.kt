package com.example.mapapp.network

import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import retrofit2.http.Field

interface ApiService {

    // 🔹 Register API
    @FormUrlEncoded
    @POST("register.php")
    fun registerUser(
        @Field("username") username: String,
        @Field("mobile_number") phoneNumber: String,
        @Field("password") password: String,
        @Field("re_enter_password") confirmPassword: String
    ): Call<RegisterResponse>

    // 🔹 Login API
    @FormUrlEncoded
    @POST("login.php")
    fun loginUser(
        @Field("mobile_number") mobileNumber: String,
        @Field("password") password: String
    ): Call<LoginResponse>

    // ✅ Missing Save Measurement API (Now Added)
    @FormUrlEncoded
    @POST("savemeasurement.php")
    fun saveMeasurement(
        @Field("user_id") userId: Int,
        @Field("area") area: Double,
        @Field("perimeter") perimeter: Double,
        @Field("unit") unit: String,
        @Field("place") place: String
    ): Call<ApiResponse>

    @FormUrlEncoded
    @POST("forgotpassword.php")
    fun resetPassword(
        @Field("mobile_number") mobileNumber: String,
        @Field("new_password") newPassword: String,
        @Field("confirm_password") confirmPassword: String
    ): Call<ForgetResponse>

    @GET("getmeasure.php")
    suspend fun getMeasurements(@Query("user_id") userId: Int): Response<MeasureResponse>





}
