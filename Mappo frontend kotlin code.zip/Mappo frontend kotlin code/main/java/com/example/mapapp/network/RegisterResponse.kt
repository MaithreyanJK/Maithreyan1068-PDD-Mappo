package com.example.mapapp.network

import com.google.gson.annotations.SerializedName

data class RegisterResponse(
    val status: Boolean,
    val message: String,
    @SerializedName("data")
    val data: String // "data" is returned as a String, not an array
)
