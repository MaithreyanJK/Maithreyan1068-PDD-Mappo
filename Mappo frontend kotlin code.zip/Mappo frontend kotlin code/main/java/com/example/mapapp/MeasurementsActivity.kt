package com.example.mapapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mapapp.network.Measurement
import com.example.mapapp.network.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MeasurementActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MeasurementAdapter
    private lateinit var layoutNoData: LinearLayout
    private lateinit var txtNoData: TextView
    private lateinit var btnMenu: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_measurements)

        // Initialize UI components
        recyclerView = findViewById(R.id.recyclerViewMeasurements)
        layoutNoData = findViewById(R.id.layoutNoData)
        txtNoData = findViewById(R.id.txtNoData)
        btnMenu = findViewById(R.id.btnMenu)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MeasurementAdapter(emptyList())
        recyclerView.adapter = adapter

        // Handle menu button click to show popup menu
        btnMenu.setOnClickListener {
            showPopupMenu()
        }

        fetchMeasurements()
    }

    private fun getUserIdFromPreferences(): String? {
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE) // Use "UserPrefs" instead of "UserSession"
        return sharedPreferences.getString("user_id", null) // Return null if not found
    }


    private fun fetchMeasurements() {
        layoutNoData.visibility = View.GONE
        recyclerView.visibility = View.GONE

        val userId = getUserIdFromPreferences()

        if (userId == null) {  // ✅ Check for null instead of -1
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.getInstance(this@MeasurementActivity).getMeasurements(userId.toInt()) // Convert to Int

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful && response.body() != null) {
                        val measurements = response.body()!!.data

                        if (measurements.isNotEmpty()) {
                            adapter.updateData(measurements)
                            recyclerView.visibility = View.VISIBLE
                            layoutNoData.visibility = View.GONE
                        } else {
                            layoutNoData.visibility = View.VISIBLE
                        }
                    } else {
                        layoutNoData.visibility = View.VISIBLE
                        Toast.makeText(this@MeasurementActivity, "Failed to fetch data", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    layoutNoData.visibility = View.VISIBLE
                    Toast.makeText(this@MeasurementActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    private fun showPopupMenu() {
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.custom_popup_menu, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        val btnHome = dialogView.findViewById<Button>(R.id.btnHome)
        val btnMeasurements = dialogView.findViewById<Button>(R.id.btnMeasurements)
        val btnRoute = dialogView.findViewById<Button>(R.id.btnRoute)
        val btnSettings = dialogView.findViewById<Button>(R.id.btnSettings)
        val btnSosEmergency = dialogView.findViewById<Button>(R.id.btnSosEmergency)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        btnHome.setOnClickListener {
            navigateTo(MapsActivity::class.java)
            dialog.dismiss()
        }
        btnMeasurements.setOnClickListener {
            navigateTo(MeasurementActivity::class.java)
            dialog.dismiss()
        }
        btnRoute.setOnClickListener {
            navigateTo(RoutePlannerActivity::class.java)
            dialog.dismiss()
        }
        btnSettings.setOnClickListener {
            navigateTo(SettingsActivity::class.java)
            dialog.dismiss()
        }
        btnSosEmergency.setOnClickListener {
            showSosBottomSheet() // Open SOS Bottom Sheet
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun navigateTo(activityClass: Class<*>) {
        val intent = android.content.Intent(this, activityClass)
        startActivity(intent)
    }

    private fun showSosBottomSheet() {
        // Implement SOS bottom sheet functionality here if required
        Toast.makeText(this, "SOS Emergency Clicked!", Toast.LENGTH_SHORT).show()
    }
}
