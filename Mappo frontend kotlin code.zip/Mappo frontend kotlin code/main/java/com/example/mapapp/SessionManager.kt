package com.example.mapapp

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
    private val editor = sharedPreferences.edit()

    fun saveLogin(userId: String, username: String) {
        editor.putString("user_id", userId)  // Ensure user_id is stored as a String
        editor.putString("username", username)
        editor.putBoolean("is_logged_in", true)
        editor.apply()
    }

    fun getUserId(): String? {
        return sharedPreferences.getString("user_id", null) // Ensures it returns a String
    }


    fun getUsername(): String? {
        return sharedPreferences.getString("username", null)
    }

    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("is_logged_in", false)
    }

    fun logout() {
        editor.clear()
        editor.apply()
    }
}

