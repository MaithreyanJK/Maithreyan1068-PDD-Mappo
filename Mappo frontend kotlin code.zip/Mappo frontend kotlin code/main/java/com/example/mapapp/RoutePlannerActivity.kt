package com.example.mapapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.common.api.ApiException
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.AutocompletePrediction
import com.google.android.libraries.places.api.model.AutocompleteSessionToken
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient

class RoutePlannerActivity : AppCompatActivity() {

    private lateinit var editTextFrom: AutoCompleteTextView
    private lateinit var editTextTo: AutoCompleteTextView
    private lateinit var buttonGetRoute: Button
    private lateinit var btnMenu: ImageButton
    private lateinit var placesClient: PlacesClient
    private lateinit var sessionToken: AutocompleteSessionToken

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_route_planner)

        // Initialize Places API
        if (!Places.isInitialized()) {
            Places.initialize(applicationContext, "AIzaSyD3_9NgruITXOrfzCFnw_vNuvGTa1IPpqc")
        }
        placesClient = Places.createClient(this)
        sessionToken = AutocompleteSessionToken.newInstance()

        // Initialize views
        editTextFrom = findViewById(R.id.editTextFrom)
        editTextTo = findViewById(R.id.editTextTo)
        buttonGetRoute = findViewById(R.id.buttonGetRoute)
        btnMenu = findViewById(R.id.btnMenu)

        // Setup autocomplete for input fields
        setupAutocomplete(editTextFrom)
        setupAutocomplete(editTextTo)

        buttonGetRoute.setOnClickListener {
            val origin = editTextFrom.text.toString()
            val destination = editTextTo.text.toString()

            if (origin.isNotEmpty() && destination.isNotEmpty()) {
                openGoogleMaps(origin, destination)
            } else {
                Toast.makeText(this, "Please enter both origin and destination", Toast.LENGTH_SHORT).show()
            }
        }

        btnMenu.setOnClickListener {
            showPopupMenu(it)
        }
    }

    private fun setupAutocomplete(autoCompleteTextView: AutoCompleteTextView) {
        autoCompleteTextView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                autoCompleteTextView.showDropDown()
            }
        }

        autoCompleteTextView.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                fetchPredictions(autoCompleteTextView, s.toString())
            }
        })

        autoCompleteTextView.setOnItemClickListener { parent, _, position, _ ->
            val selectedPlace = parent.getItemAtPosition(position) as String
            autoCompleteTextView.setText(selectedPlace)
        }
    }

    private fun fetchPredictions(autoCompleteTextView: AutoCompleteTextView, query: String) {
        if (query.isEmpty()) return

        val request = FindAutocompletePredictionsRequest.builder()
            .setSessionToken(sessionToken)
            .setQuery(query)
            .build()

        placesClient.findAutocompletePredictions(request)
            .addOnSuccessListener { response ->
                val placesList = mutableListOf<String>()
                for (prediction: AutocompletePrediction in response.autocompletePredictions) {
                    placesList.add(prediction.getPrimaryText(null).toString())
                }
                val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, placesList)
                autoCompleteTextView.setAdapter(adapter)
                autoCompleteTextView.showDropDown()
            }
            .addOnFailureListener { exception ->
                if (exception is ApiException) {
                    Log.e("PlacesAPI", "Error fetching predictions: ${exception.statusCode}")
                }
            }
    }

    private fun openGoogleMaps(origin: String, destination: String) {
        val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$destination")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        mapIntent.setPackage("com.google.android.apps.maps")

        if (mapIntent.resolveActivity(packageManager) != null) {
            startActivity(mapIntent)
        } else {
            Toast.makeText(this, "Google Maps app is not installed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPopupMenu(view: View) {
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.custom_popup_menu, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        val btnHome = dialogView.findViewById<Button>(R.id.btnHome)
        val btnMeasurements = dialogView.findViewById<Button>(R.id.btnMeasurements)
        val btnRoute = dialogView.findViewById<Button>(R.id.btnRoute)
        val btnSettings = dialogView.findViewById<Button>(R.id.btnSettings)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        btnHome.setOnClickListener {
            navigateTo(MapsActivity::class.java)
            dialog.dismiss()
        }
        btnMeasurements.setOnClickListener {
            navigateTo(MeasurementActivity::class.java)
            dialog.dismiss()
        }
        btnRoute.setOnClickListener {
            navigateTo(RoutePlannerActivity::class.java)
            dialog.dismiss()
        }
        btnSettings.setOnClickListener {
            navigateTo(SettingsActivity::class.java)
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun navigateTo(activity: Class<*>) {
        val intent = Intent(this, activity)
        startActivity(intent)
    }
}
