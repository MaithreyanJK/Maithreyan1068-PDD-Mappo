package com.example.mapapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.mapapp.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.mapapp.network.ForgetResponse


class ForgetActivity : AppCompatActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var etMobileNumber: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnResetPassword: Button
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget)

        // Initialize UI components
        btnBack = findViewById(R.id.btnBack)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etNewPassword = findViewById(R.id.etNewPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnResetPassword = findViewById(R.id.btnResetPassword)
        btnLogin = findViewById(R.id.btnLogin)

        // Back button click
        btnBack.setOnClickListener {
            finish() // Go back to the previous screen
        }

        // Login button click
        btnLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Reset Password button click
        btnResetPassword.setOnClickListener {
            validateInput()
        }
    }

    private fun validateInput() {
        val mobileNumber = etMobileNumber.text.toString().trim()
        val newPassword = etNewPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()

        when {
            mobileNumber.isEmpty() -> etMobileNumber.error = "Enter your mobile number"
            newPassword.isEmpty() -> etNewPassword.error = "Enter a new password"
            confirmPassword.isEmpty() -> etConfirmPassword.error = "Confirm your password"
            newPassword != confirmPassword -> etConfirmPassword.error = "Passwords do not match"
            else -> {
                // Proceed with API request
                resetPassword(mobileNumber, newPassword, confirmPassword)
            }
        }
    }

    private fun resetPassword(mobileNumber: String, newPassword: String, confirmPassword: String) {
        val apiService = RetrofitClient.getInstance(this) // Updated to use getInstance()

        val call = apiService.resetPassword(mobileNumber, newPassword, confirmPassword)

        call.enqueue(object : Callback<ForgetResponse> {
            override fun onResponse(call: Call<ForgetResponse>, response: Response<ForgetResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val forgetResponse = response.body()
                    if (forgetResponse?.success == true) {
                        Toast.makeText(this@ForgetActivity, "Password Reset Successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@ForgetActivity, LoginActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@ForgetActivity, forgetResponse?.message ?: "Failed to reset password", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@ForgetActivity, "Error: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ForgetResponse>, t: Throwable) {
                Toast.makeText(this@ForgetActivity, "Request failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }



}
