package com.example.mapapp

import android.os.Parcel
import android.os.Parcelable

// Data model for a marked location
data class MarkedLocation(
    val latitude: Double,      // Latitude coordinate
    val longitude: Double,     // Longitude coordinate
    val measurementType: String // "Distance" or "Area"
) : Parcelable { // Implements Parcelable to pass data efficiently

    // Constructor for parcelable implementation
    constructor(parcel: Parcel) : this(
        parcel.readDouble(),        // Read latitude from Parcel
        parcel.readDouble(),        // Read longitude from Parcel
        parcel.readString() ?: "Unknown" // Read measurement type
    )

    // Write data to Parcel for transfer
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeDouble(latitude)
        parcel.writeDouble(longitude)
        parcel.writeString(measurementType)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<MarkedLocation> {
        override fun createFromParcel(parcel: Parcel): MarkedLocation {
            return MarkedLocation(parcel)
        }

        override fun newArray(size: Int): Array<MarkedLocation?> {
            return arrayOfNulls(size)
        }
    }
}
