package com.example.mapapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient

class SearchActivity : AppCompatActivity() {

    private lateinit var placesClient: PlacesClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        // Initialize Places API client
        if (!Places.isInitialized()) {
            Places.initialize(applicationContext, "AIzaSyD3_9NgruITXOrfzCFnw_vNuvGTa1IPpqc") // Replace with your API key
        }
        placesClient = Places.createClient(this)

        val searchEditText = findViewById<AutoCompleteTextView>(R.id.etSearch)
        val searchButton = findViewById<Button>(R.id.btnSearchLocation)
        val cancelButton = findViewById<Button>(R.id.btnCancel)

        // Handle Search Button Click
        searchButton.setOnClickListener {
            val locationQuery = searchEditText.text.toString().trim()

            if (locationQuery.isNotEmpty()) {
                // Send the search query back to MapsActivity
                val resultIntent = Intent()
                resultIntent.putExtra("LOCATION_QUERY", locationQuery)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()  // Close SearchActivity and return result
            } else {
                Toast.makeText(this, "Please enter a location", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle Cancel Button Click (Closes SearchActivity)
        cancelButton.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }

        // Set up AutoCompleteTextView
        setupAutoCompleteTextView(searchEditText)
    }

    private fun setupAutoCompleteTextView(searchEditText: AutoCompleteTextView) {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line)
        searchEditText.setAdapter(adapter)

        searchEditText.setOnItemClickListener { parent, _, position, _ ->
            val selectedPlace = parent.getItemAtPosition(position) as String
            searchEditText.setText(selectedPlace)
        }

        // Correct way to add TextWatcher
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence?, start: Int, count: Int, after: Int) {
                // No implementation needed here
            }

            override fun onTextChanged(charSequence: CharSequence?, start: Int, before: Int, count: Int) {
                val query = searchEditText.text.toString()
                if (query.isNotEmpty()) {
                    fetchPlaceSuggestions(query, adapter)
                }
            }

            override fun afterTextChanged(editable: Editable?) {
                // No implementation needed here
            }
        })
    }

    private fun fetchPlaceSuggestions(query: String, adapter: ArrayAdapter<String>) {
        val request = FindAutocompletePredictionsRequest.builder()
            .setQuery(query)
            .build()

        placesClient.findAutocompletePredictions(request)
            .addOnSuccessListener { response ->
                val predictions = response.autocompletePredictions
                val suggestionList = predictions.map { it.getFullText(null).toString() }
                adapter.clear()
                adapter.addAll(suggestionList)
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error fetching suggestions: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
