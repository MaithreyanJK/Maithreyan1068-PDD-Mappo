package com.example.mapapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Initialize SessionManager
        sessionManager = SessionManager(this)

        // Find Views
        val tvUsername = findViewById<TextView>(R.id.tvUsername) // Ensure this ID exists in XML
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val btnAreaUnit = findViewById<Button>(R.id.btnAreaUnit)
        val btnDistanceUnit = findViewById<Button>(R.id.btnDistanceUnit)
        val btnContactUs = findViewById<Button>(R.id.btnContactUs)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        // Retrieve and Display Username
        val username = sessionManager.getUsername()
        tvUsername.text = username ?: "Guest" // Show "Guest" if username is null

        // Set Click Listeners
        btnMenu.setOnClickListener { showPopupMenu() }
        btnAreaUnit.setOnClickListener { showAreaUnitDialog() }
        btnDistanceUnit.setOnClickListener { showDistanceUnitDialog() }
        btnContactUs.setOnClickListener { showContactUsDialog() }
        btnLogout.setOnClickListener { showLogoutConfirmation() }
    }

    private fun showPopupMenu() {
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.custom_popup_menu, null)

        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.white)

        val btnHome = dialogView.findViewById<Button>(R.id.btnHome)
        val btnMeasurements = dialogView.findViewById<Button>(R.id.btnMeasurements)
        val btnRoute = dialogView.findViewById<Button>(R.id.btnRoute)
        val btnSettings = dialogView.findViewById<Button>(R.id.btnSettings)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)

        btnHome.setOnClickListener {
            navigateTo(MapsActivity::class.java)
            dialog.dismiss()
        }
        btnMeasurements.setOnClickListener {
            navigateTo(MeasurementActivity::class.java)
            dialog.dismiss()
        }
        btnRoute.setOnClickListener {
            navigateTo(RoutePlannerActivity::class.java)
            dialog.dismiss()
        }
        btnSettings.setOnClickListener {
            navigateTo(SettingsActivity::class.java)
            dialog.dismiss()
        }
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun navigateTo(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        startActivity(intent)
    }

    private fun showStyledUnitDialog(title: String, units: Array<String>) {
        val builder = AlertDialog.Builder(this, R.style.CustomDialogTheme)
        builder.setTitle(title)

        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_unit_selection, null)
        val listView = dialogView.findViewById<ListView>(R.id.unitListView)

        val adapter = ArrayAdapter(this, R.layout.item_unit, R.id.tvUnitName, units)
        listView.adapter = adapter

        builder.setView(dialogView)
        val dialog = builder.create()

        listView.setOnItemClickListener { _, _, position, _ ->
            Toast.makeText(this, "Selected: ${units[position]}", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showAreaUnitDialog() {
        showStyledUnitDialog("Choose area unit", arrayOf("Square meter", "Acre", "Square Inch", "Square Yard", "Square Feet"))
    }

    private fun showDistanceUnitDialog() {
        showStyledUnitDialog("Choose distance unit", arrayOf("Meter", "Feet", "Mile", "Yard", "Kilometer"))
    }


    private fun showContactUsDialog() {
        val builder = AlertDialog.Builder(this, R.style.CustomDialogTheme)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_contact_us, null)

        builder.setView(dialogView)
        val dialog = builder.create()

        dialogView.findViewById<Button>(R.id.btnClose).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showLogoutConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("Yes") { _, _ ->
                logoutUser()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun logoutUser() {
        sessionManager.logout()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
