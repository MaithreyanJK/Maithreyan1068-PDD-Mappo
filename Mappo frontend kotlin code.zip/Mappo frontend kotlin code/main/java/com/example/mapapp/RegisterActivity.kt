package com.example.mapapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mapapp.network.RegisterResponse
import com.example.mapapp.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)



        // Reference the views
        val etUsername: EditText = findViewById(R.id.etUsername)
        val etPhoneNumber: EditText = findViewById(R.id.etPhoneNumber)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val etConfirmPassword: EditText = findViewById(R.id.etConfirmPassword)
        val btnRegister: Button = findViewById(R.id.btnRegister)
        val btnLogin: Button = findViewById(R.id.btnLogin)

        // Register button click
        btnRegister.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val phoneNumber = etPhoneNumber.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (username.isEmpty()) {
                etUsername.error = "Username is required"
                return@setOnClickListener
            }
            if (phoneNumber.isEmpty() || phoneNumber.length < 10) {
                etPhoneNumber.error = "Valid phone number is required"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                etPassword.error = "Password is required"
                return@setOnClickListener
            }
            if (password != confirmPassword) {
                etConfirmPassword.error = "Passwords do not match"
                return@setOnClickListener
            }

            registerUser(username, phoneNumber, password, confirmPassword)
        }

        // Login button click
        btnLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Google Sign-In button click

    }

    // Register user via backend API
    private fun registerUser(username: String, phoneNumber: String, password: String, confirmPassword: String) {
        val apiService = RetrofitClient.getInstance(this) // Updated to use getInstance()

        val call = apiService.registerUser(username, phoneNumber, password, confirmPassword)

        println("Sending API Request: $username, $phoneNumber, $password, $confirmPassword")

        call.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                val errorBody = response.errorBody()?.string() ?: "Unknown error"
                println("API Response: ${response.code()} - $errorBody")

                if (response.isSuccessful) {
                    val result = response.body()
                    Toast.makeText(
                        this@RegisterActivity,
                        result?.message ?: "Registration failed",
                        Toast.LENGTH_LONG
                    ).show()

                    if (result?.status == true) {
                        startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
                        finish()
                    }
                } else {
                    Toast.makeText(this@RegisterActivity, "Server error: $errorBody", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                println("Network error: ${t.message}")
                Toast.makeText(this@RegisterActivity, "Network error: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }




}
