package com.example.mapapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // Set the main layout

        // Reference the views
        val tvAppName: TextView = findViewById(R.id.tvAppName)
        val ivCenterImage: ImageView = findViewById(R.id.ivCenterImage)
        val btnGetStarted: Button = findViewById(R.id.btnGetStarted)

        // Modify dynamic content if necessary
        tvAppName.text = "Mappo !"  // Set the text of TextView

        // Handle button click to start RegisterActivity
        btnGetStarted.setOnClickListener {
            // Create an Intent to start RegisterActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}
