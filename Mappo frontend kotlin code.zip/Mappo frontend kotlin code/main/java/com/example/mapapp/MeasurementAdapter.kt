package com.example.mapapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mapapp.network.Measurement

class MeasurementAdapter(private var measurements: List<Measurement>) :
    RecyclerView.Adapter<MeasurementAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val area: TextView = view.findViewById(R.id.textArea)
        val perimeter: TextView = view.findViewById(R.id.textPerimeter)
        val unit: TextView = view.findViewById(R.id.textUnit)
        val place: TextView = view.findViewById(R.id.textPlace)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_measurement, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val measurement = measurements[position]
        holder.area.text = "Area: ${measurement.area}"
        holder.perimeter.text = "Perimeter: ${measurement.perimeter}"
        holder.unit.text = "Unit: ${measurement.unit}"
        holder.place.text = "Place: ${measurement.place}"
    }

    override fun getItemCount(): Int = measurements.size

    fun updateData(newData: List<Measurement>) {
        measurements = newData
        notifyDataSetChanged()
    }
}
