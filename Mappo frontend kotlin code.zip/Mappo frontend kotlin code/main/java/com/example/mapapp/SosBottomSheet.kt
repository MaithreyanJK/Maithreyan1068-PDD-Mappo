package com.example.mapapp

import android.content.Context
import android.content.Intent
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class SosBottomSheet : BottomSheetDialogFragment() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.bottom_sheet_sos, container, false)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())

        val btnSendSms = view.findViewById<Button>(R.id.btnSendSms)
        val btnSendWhatsApp = view.findViewById<Button>(R.id.btnSendWhatsApp)
        val btnCancel = view.findViewById<Button>(R.id.btnCancel) // Added Cancel Button

        btnSendSms.setOnClickListener {
            getLastLocation { location ->
                if (location != null) {
                    sendSms(requireContext(), location)
                } else {
                    Toast.makeText(requireContext(), "Location not available", Toast.LENGTH_SHORT).show()
                }
            }
            dismissAllowingStateLoss() // Dismiss safely
        }

        btnSendWhatsApp.setOnClickListener {
            getLastLocation { location ->
                if (location != null) {
                    sendWhatsApp(requireContext(), location)
                } else {
                    Toast.makeText(requireContext(), "Location not available", Toast.LENGTH_SHORT).show()
                }
            }
            dismissAllowingStateLoss() // Dismiss safely
        }

        btnCancel.setOnClickListener {
            dismissAllowingStateLoss() // Ensure the cancel button works
        }

        return view
    }

    override fun onStart() {
        super.onStart()
        dialog?.setCancelable(true)
        dialog?.setCanceledOnTouchOutside(true) // Allow dismissal when clicking outside
    }

    private fun getLastLocation(callback: (Location?) -> Unit) {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    callback(location)
                }
                .addOnFailureListener {
                    callback(null)
                }
        } else {
            callback(null)
        }
    }

    private fun sendSms(context: Context, location: Location) {
        val message = "SOS! I need help. My location: https://maps.google.com/?q=${location.latitude},${location.longitude}"
        val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")) // Open default messaging app directly
        smsIntent.putExtra("sms_body", message)
        context.startActivity(smsIntent)
    }

    private fun sendWhatsApp(context: Context, location: Location) {
        val message = "SOS! I need help. My location: https://maps.google.com/?q=${location.latitude},${location.longitude}"

        try {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT, message)
            intent.setPackage("com.whatsapp") // Ensuring it opens WhatsApp

            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        }
    }
}
