package com.example.mapapp

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater

object LoadingDialog {
    private var dialog: Dialog? = null

    @SuppressLint("InflateParams")
    fun show(context: Context) {
        if (dialog != null && dialog!!.isShowing) return // Prevent multiple dialogs

        dialog = Dialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.progress_dialog, null)
        dialog?.setContentView(view)
        dialog?.setCancelable(false) // Prevent dismissing by back button
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog?.show()
    }

    fun dismiss() {
        dialog?.dismiss()
    }
}
